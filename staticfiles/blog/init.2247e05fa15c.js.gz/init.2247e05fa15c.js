(function($){
  $(function() {

    $('.sidenav').sidenav();
    $('.parallax').parallax();

  }); // end of doc ready
})(jQuery); // end of jQuery namespace